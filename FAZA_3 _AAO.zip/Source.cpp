﻿//ECHIPA AAO---Grupa 1059
//---Tepes-Greurus Ana-Maria
//---Tuca Oana-Bianca
//---Udrea Andra-Nicoleta

#define _CRT_SECURE_NO_WARNINGS
#pragma once
#include<iostream>
#include<string>
#include <fstream>
using namespace std;
fstream g("date.txt", ios::trunc);
fstream numeTab("numeTabele.txt", fstream::in | fstream::out | fstream::app);
ofstream fisierTabele("tabeleDate.dat", ios::binary | ios::trunc);
// CLASA PT EXCEPTIE
class Exceptie {
};

//PENTRU A CREA O TABELA AVEM NEVOIE DE MAI MULTE COLOANE
class Coloana {
	string nume_coloana = "";
	string tip = "";
	int dimensiune = 0;
	string valoare_implicita = "";
public:
	//CONSTRUCTOR FARA PARAMETRII
	Coloana() {
		this->nume_coloana = "";
		this->tip = "";
		this->dimensiune = 0;
		this->valoare_implicita = "";

	}
	//CONSTRUCTOR CU PARAMETRII
	Coloana(string nume_coloana, string tip, int dimensiune, string valoare_implicita) {
		this->nume_coloana = nume_coloana;
		this->tip = tip;
		this->dimensiune = dimensiune;
		this->valoare_implicita = valoare_implicita;

	}
	//CONSTRUCTOR CU UN SINGUR PARAMETRU
	Coloana(string nume_coloana) {
		this->nume_coloana = nume_coloana;
		this->tip = tip;
		this->dimensiune = 0;
		this->valoare_implicita = "";
	}
	//FUNCTIILE ACCESOR
	string getNume_Coloana() {
		return this->nume_coloana;
	}
	string getTip() {

		return this->tip;
	}
	int getDimensiune() {
		return this->dimensiune;
	}
	string getValoare_Implicita() {
		return this->valoare_implicita;
	}
	void setNume_Coloana(string nume_coloana) {
		this->nume_coloana = nume_coloana;
	}
	void setDimensiune(int dimensiune) {
		this->dimensiune = dimensiune;
	}

	void setTip(string tip) {
		this->tip = tip;
	}
	void setValoare_Implicita(string valoare_implicita) {
		this->valoare_implicita = valoare_implicita;
	}
	//DESTRUCTOR
	~Coloana() {

	}
	//CONSTRUCTOR DE COPIERE
	Coloana(const Coloana& c) {
		this->nume_coloana = c.nume_coloana;
		this->tip = c.tip;
		this->dimensiune = c.dimensiune;
		this->valoare_implicita = c.valoare_implicita;
	}
	//OPERATORUL =
	Coloana operator=(const Coloana& c) {
		this->nume_coloana = c.nume_coloana;
		this->tip = c.tip;
		this->dimensiune = c.dimensiune;
		this->valoare_implicita = c.valoare_implicita;
		return *this;
	}
	//OPERATORUL >>
	friend istream& operator>>(istream& intrare, Coloana& c) {
		intrare >> c.nume_coloana;
		intrare >> c.tip;
		intrare >> c.dimensiune;
		intrare >> c.valoare_implicita;
	}
	//OPERATORUL <<
	friend ostream& operator<<(ostream& monitor, Coloana c)
	{
		monitor << "Coloana se numeste " << c.nume_coloana << " este de tipul " << c.tip << " are dimensiunea" << c.dimensiune << " si valoarea implicita este" << c.valoare_implicita << endl;

		return monitor;

	}
	//OPERATOR ++(COLOANA+COLOANA)
	
	Coloana operator+(Coloana c2) {
		
		Coloana rezultat = *this;
		rezultat.dimensiune += c2.dimensiune;
		return rezultat;
	}
	//operator ++(Coloana ++)
	Coloana operator++(int) {
		//post incrementare   
		Coloana copie = *this;
		this->dimensiune += 1;
		return copie;
	}

	//operator++(++ Mesaj)
	Coloana operator++() {
		//pre-incrementare--se modifica si this
		this->dimensiune+= 1;
		return *this;

	}
	//operator ! 
	bool operator!() {
		if (this->dimensiune > 25)return true;
		else return false;
	}
	//operator cast la int (
	
	explicit operator char() {
		return this->dimensiune;
	}

	void afisareColoana() {
		cout << "Coloana se numeste " << this->nume_coloana
			<< " este de tipul " << this->tip
			<< " are dimensiunea" << this->dimensiune
			<< " si valoarea implicita este" << this->valoare_implicita << endl;

		cout << endl;
	}
};
//AM DEFINIT O CLASA PT CREAREA EFECTIVA A TABELEI
class Create {
	string nume_tabel = "";
	int nrColoane = 0;
	Coloana* coloane = nullptr;//VECTOR DINAMIC DE OBIECTE
public:
	Create() {
		this->nume_tabel = "";
		this->nrColoane = 0;
		this->coloane = new Coloana[this->nrColoane];

	}
	Create(string nume_tabel, int nrColoane, Coloana* coloane) {
		this->nume_tabel = nume_tabel;
		this->nrColoane = nrColoane;
		/*	if (this->coloane != NULL)
				delete[]this->coloane;*/
		this->coloane = new Coloana[nrColoane];
		for (int i = 0; i < nrColoane; i++) {
			this->coloane[i] = coloane[i];
		}
	}
	Create(string nume_tabel) {
		this->nume_tabel = nume_tabel;
		this->nrColoane = 0;
		this->coloane = new Coloana[this->nrColoane];

	}
	string getNume_Tabel() {
		return this->nume_tabel;
	}
	int getNrColoane() {
		return this->nrColoane;
	}
	Coloana* getColoane() {
		return this->coloane;
	}
	void setNume_Tabel(string nume_tabel) {
		this->nume_tabel = nume_tabel;
	}

	//SETTER COMPUS
	void setColoane(int nrColoane, Coloana* coloane) {
		if (nrColoane > 0) {
			if (this->coloane != NULL)
			{
				delete[] this->coloane;
			}

			this->coloane = new Coloana[nrColoane];
			for (int i = 0; i < nrColoane; i++)
				this->coloane[i] = coloane[i];

		}
		this->nrColoane = nrColoane;

	}
	~Create() {
		if (this->coloane != NULL) {
			delete[]this->coloane;
		}
	}
	Create(const Create& f) {
		this->nume_tabel = f.nume_tabel;
		this->nrColoane = f.nrColoane;
		this->coloane = new Coloana[f.nrColoane];
		for (int i = 0; i < f.nrColoane; i++) {
			this->coloane[i] = f.coloane[i];
		}
	}
	Create operator=(const Create& f) {
		this->nume_tabel = f.nume_tabel;
		this->nrColoane = f.nrColoane;
		this->coloane = new Coloana[f.nrColoane];
		for (int i = 0; i < f.nrColoane; i++) {
			this->coloane[i] = f.coloane[i];
		}
		return *this;
	}
	friend istream& operator>>(istream& citire, Create& f) {
		citire >> f.nume_tabel;
		citire >> f.nrColoane;

		if (f.coloane != NULL) {
			delete[]f.coloane;
		}
		f.coloane = new Coloana[f.nrColoane];
		for (int i = 0; i < f.nrColoane; i++)
			citire >> f.coloane[i];

	}
	friend ostream& operator<<(ostream& afisare, Create f) {
		afisare << "Tabela creata se numeste : " << f.nume_tabel << " cu  " << f.nrColoane << " coloane :";
		for (int i = 0; i < f.nrColoane; i++)
		{
			afisare << f[i];
			afisare << endl;
		}
		afisare << endl;
		return afisare;
	}

	// OPERATORUL [] INDEXARE
	Coloana& operator[](int index) {
		if (index >= 0 && index < this->nrColoane) {
			return this->coloane[index];
		}
	}
	void afisareTabela() {
		if (this->nrColoane != 0)
		{
			cout << "Tabela  " << this->nume_tabel << " cu  " << this->nrColoane << " coloane :";
               cout << endl;
			for (int i = 0; i < this->nrColoane; i++)
			{
				cout << this->coloane[i].getNume_Coloana() << " " << this->coloane[i].getTip() << " " << this->coloane[i].getDimensiune() << " " << this->coloane[i].getValoare_Implicita() << endl;
				
			}
			//cout << endl;
		}
	}
	//afisare tabela in fisier binar
	void scrieTabela(ofstream& fisierBinar) {
		//scriem numele tabelei
		int nrCaractereCuTerminator0 = this->nume_tabel.size() + 1;
		fisierBinar.write((char*)&nrCaractereCuTerminator0, sizeof(int));
		//numele tabelei +/0
		fisierBinar.write(this->nume_tabel.c_str(), nrCaractereCuTerminator0 * sizeof(char));
		//scriu nr de coloane
		fisierBinar.write((char*)&this->nrColoane, sizeof(int));
		//pt vecorul de coloane:
		for (int i = 0; i < this->nrColoane; i++) {
			//afisam numele coloanei
			int nrCaractereCuTerminator1 = this->coloane[i].getNume_Coloana().size() + 1;
			fisierBinar.write((char*)&nrCaractereCuTerminator1, sizeof(int));
			//scriu denumirea coloanei+ /0
			fisierBinar.write(this->coloane[i].getNume_Coloana().c_str(), nrCaractereCuTerminator1 * sizeof(char));
			//scriu tipul coloanei-string 
			int nrCaractereCuTerminator2 = this->coloane[i].getTip().size() + 1;
			fisierBinar.write((char*)&nrCaractereCuTerminator2, sizeof(int));
			fisierBinar.write(this->coloane[i].getTip().c_str(), nrCaractereCuTerminator2 * sizeof(char));
			//dimensiune
			int terminator = this->coloane[i].getDimensiune();
			fisierBinar.write((char*)&terminator, sizeof(int));
			//valoare implicita-string
			int nrCaractereCuTerminator3 = this->coloane[i].getValoare_Implicita().size() + 1;
			fisierBinar.write((char*)&nrCaractereCuTerminator3, sizeof(int));
			fisierBinar.write(this->coloane[i].getValoare_Implicita().c_str(), nrCaractereCuTerminator3 * sizeof(char));
		}

	}
	//functie care afiseaza numele tabelei 
	virtual void functieAfis() {
		cout << "Numele tabelei este: " << this->nume_tabel;
	}

};
// AM DEFINIT O CLASA PT AFISAREA TABELEI

class Display {

	Create c;
public:
	Display() {

		this->c.setNume_Tabel("hh");
		this->c.setColoane(0, nullptr);
	}
	Display(Create tabela) {
		this->c.setNume_Tabel(tabela.getNume_Tabel());
		this->c.setColoane(tabela.getNrColoane(), tabela.getColoane());

	}
	void afisare() {
		c.afisareTabela();
	}

};
//AM DEFINIT O CLASA PT STERGEREA TABELEI
class Drop {

	Create c;
public:
	Drop() {

		this->c.setNume_Tabel("");
		this->c.setColoane(0, nullptr);
	}
	Drop(Create tabela) {
		this->c.setNume_Tabel(tabela.getNume_Tabel());
		this->c.setColoane(0, nullptr);

	}
	void afisare() {
		cout << " Tabela " << this->c.getNume_Tabel() << " a fost stearsa ";
		this->c.afisareTabela();
	}
	void stergereInregistrari_nume_tabel() {
		char char_nume_tabel[30] = "";

		strcpy(char_nume_tabel, this->c.getNume_Tabel().c_str());
		strcat(char_nume_tabel, ".bin");


		ifstream Fisier(c.getNume_Tabel() + ".bin", ios::_Nocreate);
		Fisier.close();

		if (Fisier.fail() == 0)
		{
			Fisier.close();
			remove(char_nume_tabel);
			cout << "Fisierul a fost sters" << endl;
		}
		else {
			cout << "Fisierul nu exista";
		}
	}

};


//CREATE TABLE students ((id, integer, 1000, 0), (nume, text, 128, ’’), (grupa, text,50,’1000’))
//CREATE TABLE numeTabela((nume_coloană_1, tip, dimensiune, valoare_implicită), (nume_coloană_2, tip, dimensiune, valoare_implicită), ...))
//INSERT INTO nume_tabela VALUES(...); valorile sunt separate prin, și au numărul și ordinea exacta ca definiția tabelului

//VERIFICAM TIPUL DE COMANDA CRUD SI CORECTITUDINEA LOR
class ComenziCrudInsert {
	string comandaCrudInsert;
public:
	ComenziCrudInsert() {
		this->comandaCrudInsert = "";
	}

	ComenziCrudInsert(string comandaCrudInsert) {
		this->comandaCrudInsert = comandaCrudInsert;

	}
	string getComenziCrudInsert() {
		return this->comandaCrudInsert;
	}
	void setComenziCrudInsert(string comandaCrudInsert) {

		this->comandaCrudInsert = comandaCrudInsert;
	}
	~ComenziCrudInsert() {

	}
	ComenziCrudInsert(const ComenziCrudInsert& c) {
		this->comandaCrudInsert = c.comandaCrudInsert;
	}
	ComenziCrudInsert operator=(const ComenziCrudInsert& c) {
		this->comandaCrudInsert = c.comandaCrudInsert;
		return *this;
	}

	friend istream& operator>>(istream& citire, ComenziCrudInsert& c) {
		citire >> c.comandaCrudInsert;
	}
	friend ostream& operator<<(ostream& afisare, ComenziCrudInsert c) {
		afisare << "Comanda introdusa este :" << c.comandaCrudInsert;
		afisare << endl;
		return afisare;
	}
	// VERIFICAM AL DOILEA CUVANT INTRODUS DE LA TASTATURA DOAR PENTRU COMANDA INSERT
	void functieCrudInsert() {

		string aux2;
		int index = 6;//ne pozitionam la finalul cuvantului INSERT
		while (this->comandaCrudInsert[index] == ' ')index++;
		while ((this->comandaCrudInsert[index] != NULL) && (this->comandaCrudInsert[index] != ' ')) {
			aux2 += this->comandaCrudInsert[index];
			index++;
		}
		index++;//sarim peste spatiu
		if (aux2 == "INTO") {
			//cout << "Se incearca inserarea";
			//INSERT INTO studenti VALUES (1,”John”,”1001”)
			//-----------CONTINUAM --VERIFICAM DACA A FOST INTRODUS NUMELE TABELEI
			string aux3 = "";
			while (this->comandaCrudInsert[index] != ' ' && index != this->comandaCrudInsert.length()) {

				aux3 += this->comandaCrudInsert[index];
				index++;
			}
			int ok2 = 0; string s = "";
			numeTab.open("numeTabele", fstream::in | fstream::app);

			while (getline(numeTab, s) && ok2 == 0) {

				if (s == aux3)ok2 = 1;

			}
			numeTab.close();
			if (ok2 == 0)aux3 = "";
			if (aux3.length() < 2 || aux3 == "VALUES")cout << endl << "dar,nu ai introdus numele tabelei sau tabela nu exista!";
			else {//este introdus corect numele tabelei ,continuam verificarea
				cout << " in tabela " << aux3;
				//verificam daca urmatorul cuvant este VALUES
				string aux4 = "";
				index++;
				while (this->comandaCrudInsert[index] != ' ' && index != this->comandaCrudInsert.length()) {

					aux4 += this->comandaCrudInsert[index];
					index++;
				}
				if (aux4 != "VALUES") { cout << endl << " ,dar al treilea cuvant cheie al comenzii este gresit !"; }
				else if (aux4 == "VALUES")
				{
					//CONTINUAM ,VERIFICAM DACA VALORIILE SUNT INTRODUSE CORECT
					index++;
					if (this->comandaCrudInsert[index] != '(' || this->comandaCrudInsert[this->comandaCrudInsert.length() - 1] != ')')
						cout << endl << ",dar lipseste paranteza";
					else {
						index++;
						int semafor = 1;
						int nrColoane = 0;
						string aux5[100];
						while (index != this->comandaCrudInsert.length() && semafor == 1)
						{
							aux5[nrColoane] = "";
							while (this->comandaCrudInsert[index] != ','
								&& this->comandaCrudInsert[index] != ')'
								/*&& this->comandaCrudInsert[index] != ' '*/) {
								aux5[nrColoane] += this->comandaCrudInsert[index];
								index++;
							}

							if (this->comandaCrudInsert[index] != ')') {
								if (this->comandaCrudInsert[index] != ',') {
									cout << endl << ",dar lipseste ,";
									semafor = 0;
								}
								else index++;
							}
							else if (this->comandaCrudInsert[index] == ')') {
								index = index + 1;

								//Am separat fiecare coloana pt exemplul INSERT INTO studenti VALUES (1,”John”,”1001”)-avem 1,''john'',''1001''

							}
							nrColoane++;
						}
						if (semafor == 1) {
							string ajutator = "Inregistrari_"+aux3;
							ofstream fi((ajutator) + ".bin", ios::binary | ios::app);
							cout << endl << " Felicitari!Ai introdus corect si se vor insera in tabela "
								<< aux3 << " :" << endl;
							for (int i = 0; i < nrColoane; i++) {
								cout << "Coloana " << i + 1 << " value :";
								if (aux5[i][0] != '"')
								{
									int nrCaractereCuTerminator0 = aux5[i].size() + 1;
									fi.write((char*)&nrCaractereCuTerminator0, sizeof(int));
									//valoarea +/0
									fi.write(aux5[i].c_str(), nrCaractereCuTerminator0 * sizeof(char));





									cout << aux5[i] << endl;
								}
								else { int nrCaractereCuTerminator0 = aux5[i].size() - 1;
								fi.write((char*)&nrCaractereCuTerminator0, sizeof(int));
								for (int j = 1; j < aux5[i].length() - 1; j++)
								{
									fi.write((char*)&aux5[i][j], sizeof(char));
									cout << aux5[i][j];
									
								}
								cout << endl;
								}
							}

						}

					}

				}

			}

		}

		else if (aux2 != "INTO") {
			cout << "Al doilea cuvant cheie gresit!";
		}

	}

};
//Clasa care genereaza automat un fisierbinar
class fisier {
	string nume_fisier = "";
public:
	fisier(string nume_fisier) {
		this->nume_fisier = nume_fisier;
	}
	string getNume_fisier() {
		return this->nume_fisier;
	}
};

// AM CREAT O CLASA PENTRU COMANDA CRUD DELETE
class ComenziCrudDelete {
	string comandaCrudDelete;
public:
	ComenziCrudDelete() {
		this->comandaCrudDelete = "";
	}

	ComenziCrudDelete(string comandaCrudDelete) {
		this->comandaCrudDelete = comandaCrudDelete;

	}
	string getComenziCrudDelete() {
		return this->comandaCrudDelete;
	}
	void setComenziCrudDelete(string comandaCrudDelete) {

		this->comandaCrudDelete = comandaCrudDelete;
	}
	~ComenziCrudDelete() {

	}
	ComenziCrudDelete(const ComenziCrudDelete& c) {
		this->comandaCrudDelete = c.comandaCrudDelete;
	}
	ComenziCrudDelete operator=(const ComenziCrudDelete& c) {
		this->comandaCrudDelete = c.comandaCrudDelete;
		return *this;
	}

	friend istream& operator>>(istream& citire, ComenziCrudDelete& c) {
		citire >> c.comandaCrudDelete;
	}
	friend ostream& operator<<(ostream& afisare, ComenziCrudDelete c) {
		afisare << "Comanda introdusa este :" << c.comandaCrudDelete;
		afisare << endl;
		return afisare;
	}
	// VERIFICAM AL DOILEA CUVANT INTRODUS DE LA TASTATURA DOAR PENTRU COMANDA DELETE+NUMELE TABELEI
	void functieCrudDelete() {
		string aux2;
		int index = 6;
		while (this->comandaCrudDelete[index] == ' ')index++;
		while ((this->comandaCrudDelete[index] != NULL) && (this->comandaCrudDelete[index] != ' '))
		{
			aux2 += this->comandaCrudDelete[index];
			index++;
		}

		index++;//SARIM PESTE SPATIU

		if (aux2 == "FROM") {
			//cout << " Se incearca stergerea din tabela";
			//DELETE FROM studenti WHERE nume_coloana=valoare;
			// --VERIFICAM DACA A FOST INTRODUS NUMELE TABELEI
			string aux3 = "";
			while (this->comandaCrudDelete[index] != ' ' && index != this->comandaCrudDelete.length()) {
				if (this->comandaCrudDelete[index] == NULL)break;

				aux3 += this->comandaCrudDelete[index];
				index++;
			}
			int ok2 = 0; string s = "";
			numeTab.open("numeTabele", fstream::in | fstream::app);

			while (getline(numeTab, s) && ok2 == 0) {

				if (s == aux3)ok2 = 1;

			}
			numeTab.close();
			if (ok2 == 0)aux3 = "";
			if (aux3.length() < 2 || aux3 == "WHERE") { cout << endl << " Nu ai introdus numele tabelei sau tabela nu exista!"; }
			else {
				index++;//SARIM PESTE SPATIU
				//este introdus corect numele tabelei ,continuam verificarea
				cout << " in tabela " << aux3;
				//verificam daca urmatorul cuvant este WHERE
				string aux4 = "";

				while (this->comandaCrudDelete[index] != ' ' && index != this->comandaCrudDelete.length() - 1) {
					aux4 += this->comandaCrudDelete[index];
					index++;
				}

				if (aux4 != "WHERE" || aux4 == "") {
					cout << endl << " ,dar al treilea cuvant cheie al comenzii este gresit !";
				}
				else if (aux4 == "WHERE")
				{
					//CONTINUAM ,VERIFICAM DACA URMEAZA NUMELE COLOANEI 
					index++;
					string aux5 = "";

					while (this->comandaCrudDelete[index] != '=' && index != this->comandaCrudDelete.length() - 1) {

						aux5 += this->comandaCrudDelete[index];
						index++;
					}
					if (aux5.length() < 2 || aux5 == "=") { cout << endl << "dar,nu ai introdus numele coloanei!"; }
					else {
						int semafor = 1;
						int i = 0;
						while (i < aux5.length() - 1) {
							if (aux5[i] == ',')semafor = 0;
							i++;
						}

						if (semafor == 1) {

							while (this->comandaCrudDelete[index] != '=' && index != comandaCrudDelete.length() - 1) {
								index++;
							}

							string aux7 = "";
							if (this->comandaCrudDelete[index] != '=') {
								cout << endl << "nu ati introdus ="; semafor = 0;
							}
							else {
								index++;
								while (this->comandaCrudDelete[index] == ' ')index++;

								while (this->comandaCrudDelete[index] != ' '
									&& index != this->comandaCrudDelete.length()) {
									aux7 += this->comandaCrudDelete[index];
									index++;
								}

								if (aux7.length() < 1 || aux7 == "") {
									cout << endl << "dar,nu ai introdus valoarea"; semafor = 0;
								}

							}
							if (semafor == 1)
								cout << endl << "Felicitari! Ati sters coloana " << aux5 << "cu valoarea :" << aux7;

						}

						else if (semafor == 0) cout << endl << ",dar ai prea multe conditii pentru where";

					}

				}
			}
		}
		else if (aux2 != "FROM") {
			cout << "Al doilea cuvant cheie gresit!";

		}
	}
};

//

class ComenziCrudUpdate {
	string comandaCrudUpdate;
public:
	ComenziCrudUpdate() {
		this->comandaCrudUpdate = "";
	}

	ComenziCrudUpdate(string comandaCrudUpdate) {
		this->comandaCrudUpdate = comandaCrudUpdate;

	}
	string getComenziCrudUpdate() {
		return this->comandaCrudUpdate;
	}
	void setComenziCrudUpdate(string comandaCrudUpdate) {

		this->comandaCrudUpdate = comandaCrudUpdate;
	}
	~ComenziCrudUpdate() {

	}
	ComenziCrudUpdate(const ComenziCrudUpdate& c) {
		this->comandaCrudUpdate = c.comandaCrudUpdate;
	}
	ComenziCrudUpdate operator=(const ComenziCrudUpdate& c) {
		this->comandaCrudUpdate = c.comandaCrudUpdate;
		return *this;
	}

	friend istream& operator>>(istream& citire, ComenziCrudUpdate& c) {
		citire >> c.comandaCrudUpdate;
	}
	friend ostream& operator<<(ostream& afisare, ComenziCrudUpdate c) {
		afisare << "Comanda introdusa este :" << c.comandaCrudUpdate;
		afisare << endl;
		return afisare;
	}
	// VERIFICAM AL DOILEA CUVANT INTRODUS DE LA TASTATURA DOAR PENTRU COMANDA UPDATE
	void functieCrudUpdate() {
		string aux2 = "";
		int index = 6;
		while (this->comandaCrudUpdate[index] == ' ')index++;//SAR PESTE SPATIU

		while ((this->comandaCrudUpdate[index] != NULL) && (this->comandaCrudUpdate[index] != ' ')) {
			aux2 += this->comandaCrudUpdate[index];
			index++;

		}


		while (this->comandaCrudUpdate[index] != ' ' && index != this->comandaCrudUpdate.length()) {
			if (this->comandaCrudUpdate[index] == NULL)break;
			aux2 += this->comandaCrudUpdate[index];
			index++;
		}

		int ok2 = 0; string s = "";
		numeTab.open("numeTabele", fstream::in | fstream::app);

		while (getline(numeTab, s) && ok2 == 0) {

			if (s == aux2)ok2 = 1;

		}
		numeTab.close();
		if (ok2 == 0)aux2 = "";
		if (aux2.length() < 2 || aux2 == "SET")  cout << endl << " Nu ai introdus numele tabelei sau tabela nu exista!";
		else {

			//este introdus corect numele tabelei ,continuam verificarea
			cout << endl << " Se incearca modificarea tabelei " << aux2;
			//verificam daca urmatorul cuvant este SET
			string aux3 = "";
			index++;//SAR PESTE SPATIU
			while (this->comandaCrudUpdate[index] != ' ' && index != this->comandaCrudUpdate.length()) {
				aux3 += this->comandaCrudUpdate[index];
				index++;
			}

			if (aux3 != "SET" || aux3 == "") {
				cout << endl << " ,dar al treilea cuvant cheie al comenzii este gresit !";
			}
			else if (aux3 == "SET")
			{
				//CONTINUAM ,VERIFICAM DACA URMEAZA NUMELE COLOANEI 
				index++;//SAR PESTE SPATIU
				string aux4 = "";
				while (this->comandaCrudUpdate[index] != '=' && index != this->comandaCrudUpdate.length() - 1) {

					aux4 += this->comandaCrudUpdate[index];
					index++;
				}

				if (aux4.length() < 2 || aux4 == "=")cout << endl << "dar,nu ai introdus numele coloanei!";
				else {
					int semafor = 1;
					int i = 0;
					while (i < aux4.length() - 1) {
						if (aux4[i] == ',')semafor = 0;
						i++;
					}

					if (semafor == 1) {

						while (this->comandaCrudUpdate[index] != '=' && index != comandaCrudUpdate.length() - 1) {
							index++;
						}

						if (this->comandaCrudUpdate[index] != '=') cout << endl << " nu ati introdus =";
						else {
							index++;
							if (this->comandaCrudUpdate[index] == ' ')index++;
							string aux5 = "";
							while (this->comandaCrudUpdate[index] != ' ' && index != this->comandaCrudUpdate.length() - 1) {
								aux5 += this->comandaCrudUpdate[index];
								index++;
							}


							if (aux5.length() < 1 || aux5 == "") { cout << endl << "dar,nu ai introdus valoarea"; }

							else {
								cout << " cu coloana: " << aux4 << " " << "si cu valoarea:" << aux5;
								//verificam daca urmatorul cuvant este WHERE
								string aux6 = "";
								index++;
								while (this->comandaCrudUpdate[index] != ' ' && index != this->comandaCrudUpdate.length()) {

									aux6 += this->comandaCrudUpdate[index];
									index++;
								}

								if (aux6 != "WHERE" || aux6 == "") {
									cout << endl << " ,dar al saselea cuvant cheie al comenzii este gresit !";
								}

								else if (aux6 == "WHERE") {

									//CONTINUAM ,VERIFICAM DACA URMEAZA NUMELE COLOANEI 
									index++;
									string aux7 = "";

									while (this->comandaCrudUpdate[index] != '='
										&& index != this->comandaCrudUpdate.length() - 1) {

										aux7 += this->comandaCrudUpdate[index];
										index++;
									}
									if (aux7.length() < 2 || aux7 == "=")
										cout << endl << "dar,nu ai introdus numele coloanei!";
									else {
										int ok = 1;
										int j = 0;
										while (j < aux7.length() - 1) {
											if (aux7[j] == ',')ok = 0;
											j++;
										}

										if (ok == 1) {

											while (this->comandaCrudUpdate[index] != '='
												&& index != comandaCrudUpdate.length() - 1) {
												index++;
											}

											if (this->comandaCrudUpdate[index] != '=')
												cout << endl << "nu ati introdus =";
											else {
												index++;
												while (this->comandaCrudUpdate[index] == ' '
													&& index != this->comandaCrudUpdate.length())index++;
												string aux8 = "";
												while (this->comandaCrudUpdate[index] != ' '
													&& index != this->comandaCrudUpdate.length()) {
													aux8 += this->comandaCrudUpdate[index];
													index++;
												}

												if (aux8.length() < 1 || aux8 == "" || this->comandaCrudUpdate[index] != NULL) {
													cout << endl << "dar,nu ai introdus valoarea";
												}
												else cout << endl << " Felicitari ati modificat coloana " << aux7 << " "
													<< "cu valoarea " << aux8 << " din tabela : " << aux2;
											}
										}
										else if (ok == 0)cout << " Gresit";
									}
								}
							}
						}
					}
					else if (semafor == 0) cout << endl << ",dar ai prea multe conditii pentru set";

				}
			}
		}
	}
};


//SELECT (cel_putin_o_coloana, ...) | ALL FROM nume_tabela [WHERE nume_coloană = valoare]
////AM CREAT O CLASA PENTRU COMANDA CRUD SELECT
class ComenziCrudSelect {
	string comandaCrudSelect;
public:
	ComenziCrudSelect() {
		this->comandaCrudSelect = "";
	}
	ComenziCrudSelect(string comandaCrudSelect) {
		this->comandaCrudSelect = comandaCrudSelect;
	}
	string getComenziCrudSelect() {
		return this->comandaCrudSelect;
	}
	void setComenziCrudSelect(string comandaCrudSelect) {
		this->comandaCrudSelect = comandaCrudSelect;
	}
	~ComenziCrudSelect() {

	}
	ComenziCrudSelect(const ComenziCrudSelect& c) {
		this->comandaCrudSelect = c.comandaCrudSelect;
	}
	ComenziCrudSelect operator=(const ComenziCrudSelect& c) {
		this->comandaCrudSelect = c.comandaCrudSelect;
		return *this;
	}

	friend istream& operator>>(istream& citire, ComenziCrudSelect& c) {
		citire >> c.comandaCrudSelect;
	}
	friend ostream& operator<<(ostream& afisare, ComenziCrudSelect c) {
		afisare << "Comanda introdusa este :" << c.comandaCrudSelect;
		afisare << endl;
		return afisare;
	}

	void functieCrudSelect() {
		int ok = 1;
		int nrColoane = 0;
		string auxNou[100];
		string aux2;
		string aux3;


		string aux4;
		int index = 6;//NE POZITIONAM LA FINALUL CUVANTULUI SELECT,PANA ACOLO AM VERIFICAT DEJA
		while (this->comandaCrudSelect[index] == ' ')index++;//SAR PESTE SPATIU

		while ((this->comandaCrudSelect[index] != NULL) && (this->comandaCrudSelect[index] != ' ')) {
			aux2 += this->comandaCrudSelect[index];
			index++;
		}

		index++;//SAR PESTE URMATORUL SPATIU

		if (aux2 != "ALL" && aux2[0] != '(') {
			cout << "Al doilea cuvant cheie este gresit (ALL)";

		}

		else if (aux2 == "ALL" || aux2[0] == '(')
		{
			if (aux2[0] == '(') {

				if (aux2[aux2.length() - 1] != ')') { ok = 0; cout << ", dar nu se inchide paranteza"; }
				int i = 1;
				if (aux2[i] != ')') {
					while (aux2[i] != ')' && i != aux2.length() && ok == 1)

					{
						auxNou[nrColoane] = "";

						while (aux2[i] != ',' && aux2[i] != ')' && aux2[i] != ' ') {

							auxNou[nrColoane] += aux2[i];
							i++;

						}
						if (aux2[i] != ')')
						{
							if (aux2[i] != ',') {
								cout << endl << "lipseste ,";
								ok = 0;
							}
							else i++;
						}
						else if (aux2[i] == ')') {
							i++;
						}
						nrColoane++;

					}

					while (this->comandaCrudSelect[index] == ' ')index++;
					while ((this->comandaCrudSelect[index] != NULL) && (this->comandaCrudSelect[index] != ' '))
					{
						aux3 += this->comandaCrudSelect[index];
						index++;
					}

					index++;

					if (aux3 != "FROM") {
						cout << "Al treilea cuvant cheie este gresit (FROM) ";
					}
					else
					{
						while (this->comandaCrudSelect[index] == ' ')index++;
						string aux4 = "";
						while (this->comandaCrudSelect[index] != ' ' && index != this->comandaCrudSelect.length()) {
							if (this->comandaCrudSelect[index] == NULL)break;
							aux4 += this->comandaCrudSelect[index];
							index++;

						}
						int ok2 = 0; string s = "";
						numeTab.open("numeTabele", fstream::in | fstream::app);

						while (getline(numeTab, s) && ok2 == 0) {

							if (s == aux4) { ok2 = 1; 
							cout << "Datele cerute sunt afisate in fisierul : Inregistrari_" << s << ".bin";
							}

						}
						numeTab.close();
						
						if (ok2 == 0)aux4 = "";

						if (aux4.length() < 1 || aux4 == "WHERE") { cout << endl << "Nu ai introdus numele tabelei sau tabela nu exista!"; }
						else {
							while (this->comandaCrudSelect[index] == ' ')index++;
							//verificam daca urmatorul cuvant este WHERE
							string aux5 = "";

							while (this->comandaCrudSelect[index] != ' ' && index != this->comandaCrudSelect.length()) {
								aux5 += this->comandaCrudSelect[index];
								index++;

							}

							while (this->comandaCrudSelect[index] == ' ')index++;

							if (aux5 != "WHERE" && index != this->comandaCrudSelect.length()) {
								cout << endl << "Al cincelea cuvant cheie al comenzii este gresit (WHERE) !";
							}

							else if (this->comandaCrudSelect.length() == index) {
								cout << endl << "Felicitari! Comanda a fost introdusa corect." << endl;
								cout << "tabela:" << aux4 << endl;
								if (aux2 == "ALL") {
									cout << "coloane:" << "toate" << endl;
								}
								else {
									cout << "coloane:" << nrColoane << endl;
									cout << "coloane:";
									for (int i = 0; i < nrColoane - 1; i++)
										cout << auxNou[i] << ",";
									cout << auxNou[nrColoane - 1];
									cout << endl;
								}
								cout << "filtru:" << "nu" << endl;
								cout << "coloana filtru:";
							}
							else if (aux5 == "WHERE") {
								//CONTINUAM ,VERIFICAM DACA URMEAZA NUMELE COLOANEI 
								string aux6 = "";

								while (this->comandaCrudSelect[index] != '=') {

									aux6 += this->comandaCrudSelect[index];
									index++;

								}
								if (aux6.length() < 1 || aux6 == "=") { cout << endl << "Nu ai introdus numele coloanei!"; }
								else {
									int semafor = 1;
									int i = 0;
									while (i < aux6.length() - 1) {
										if (aux6[i] == ',')semafor = 0;
										i++;
									}

									if (semafor == 1) {

										while (this->comandaCrudSelect[index] != '=' && index != this->comandaCrudSelect.length() - 1) {
											index++;


										}

										string aux7 = "";
										if (this->comandaCrudSelect[index] != '=') { cout << endl << "nu ati introdus ="; semafor = 0; }
										else {
											index++;
											while (this->comandaCrudSelect[index] == ' ')index++;

											while (this->comandaCrudSelect[index] != ' '
												&& index != this->comandaCrudSelect.length()) {
												aux7 += this->comandaCrudSelect[index];
												index++;
											}

											if (aux7.length() < 1 || aux7 == "") {
												cout << endl << "nu ai introdus valoarea"; semafor = 0;
											}

										}
										if (semafor == 1) {

											cout << endl << "Felicitari! Comanda a fost introdusa corect " << endl;
											cout << "tabela:" << aux4 << endl;
											if (aux2 == "ALL" && ok == 1) {
												cout << "coloane:" << "toate" << endl;

											}
											else {
												cout << "coloane:" << nrColoane << endl;
												cout << "coloane:";
												for (int i = 0; i < nrColoane - 1; i++)
													cout << auxNou[i] << ",";
												cout << auxNou[nrColoane - 1];
												cout << endl;

											}
											cout << "filtru:" << "da" << endl;
											cout << "coloana filtru:" << aux6 << "cu valoarea " << aux7;

										}

										else if (semafor == 0) cout << endl << ",dar ai prea multe conditii pentru where";

									}

								}
							}
						}

					}

				}
				else if (aux2[1] == ')') cout << "lipseste comanda";

				else if (aux2[0] != '(')

				{
					while ((this->comandaCrudSelect[index] != NULL) && (this->comandaCrudSelect[index] != ' '))
					{
						aux3 += this->comandaCrudSelect[index];
						index++;

					}

					index++;

					if (aux3 != "FROM") {
						cout << "Al treilea cuvant cheie este gresit (FROM) ";
					}
					else
					{
						string aux4 = "";
						while (this->comandaCrudSelect[index] != ' ' && index != this->comandaCrudSelect.length()) {
							if (this->comandaCrudSelect[index] == NULL)break;
							aux4 += this->comandaCrudSelect[index];
							index++;


						}
						if (aux4.length() < 1 || aux4 == "WHERE") { cout << endl << "Nu ai introdus numele tabelei!"; }
						else {
							//index++;
							while (this->comandaCrudSelect[index] == ' ')index++;

							//verificam daca urmatorul cuvant este WHERE
							string aux5 = "";

							while (this->comandaCrudSelect[index] != ' ' && index != this->comandaCrudSelect.length()) {
								aux5 += this->comandaCrudSelect[index];
								index++;

							}

							while (this->comandaCrudSelect[index] == ' ')index++;


							if (aux5 != "WHERE" && index != this->comandaCrudSelect.length()) {
								cout << endl << "Al cincelea cuvant cheie al comenzii este gresit (WHERE) !";
							}


							else if (this->comandaCrudSelect.length() == index) {
								cout << endl << "Felicitari! Comanda a fost introdusa corect." << endl;
								cout << "tabela:" << aux4 << endl;
								if (aux2 == "ALL") {
									cout << "coloane:" << "toate" << endl;
								}
								else {
									cout << "coloane:" << nrColoane << endl;
									cout << "coloane:";
									for (int i = 0; i < nrColoane - 1; i++)
										cout << auxNou[i] << ",";
									cout << auxNou[nrColoane - 1];
									cout << endl;
								}

								cout << "filtru:" << "nu" << endl;
								cout << "coloana filtru:";
							}
							else if (aux5 == "WHERE") {
								//CONTINUAM ,VERIFICAM DACA URMEAZA NUMELE COLOANEI 
								string aux6 = "";

								while (this->comandaCrudSelect[index] != '=') {

									aux6 += this->comandaCrudSelect[index];
									index++;
								}
								if (aux6.length() < 1 || aux6 == "=") { cout << endl << "Nu ai introdus numele coloanei!"; }
								else {
									int semafor = 1;
									int i = 0;
									while (i < aux6.length() - 1) {
										if (aux6[i] == ',')semafor = 0;
										i++;
									}

									if (semafor == 1) {

										while (this->comandaCrudSelect[index] != '='
											&& index != this->comandaCrudSelect.length() - 1) {
											index++;

										}

										string aux7 = "";
										if (this->comandaCrudSelect[index] != '=') { cout << endl << "nu ati introdus ="; semafor = 0; }
										else {
											index++;
											while (this->comandaCrudSelect[index] == ' ')index++;

											while (this->comandaCrudSelect[index] != ' '
												&& index != this->comandaCrudSelect.length()) {
												aux7 += this->comandaCrudSelect[index];
												index++;
											}


											if (aux7.length() < 1 || aux7 == "") {
												cout << endl << "nu ai introdus valoarea"; semafor = 0;
											}

										}
										if (semafor == 1) {

											cout << endl << "Felicitari! Comanda a fost introdusa corect " << endl;
											cout << "tabela:" << aux4 << endl;
											if (aux2 == "ALL" && ok == 1) {
												cout << "coloane:" << "toate" << endl;

											}
											else {
												cout << "coloane:" << nrColoane << endl;
												cout << "coloane:";
												for (int i = 0; i < nrColoane - 1; i++)
													cout << auxNou[i] << ",";
												cout << auxNou[nrColoane - 1];
												cout << endl;
											}

											cout << "filtru:" << "da" << endl;
											cout << "coloana filtru:" << aux6 << "cu valoarea " << aux7;

										}

										else if (semafor == 0) cout << endl << ",dar ai prea multe conditii pentru where";

									}

								}
							}
						}

					}
				}

			}


		}
	}

};



// AM DEFINIT O CLASA CARE VERIFICA COMANDA CREATE INTRODUSA DE LA TASTATURA
class VerificValoriPtCreate {
	string valori;

public:
	VerificValoriPtCreate()
	{
		this->valori = "";
	}
	string getValori() {
		return this->valori;
	}
	void setValori() {
		this->valori = valori;

	}

	VerificValoriPtCreate(string valori) {

		this->valori = valori;

	}
	~VerificValoriPtCreate() {

	}


	VerificValoriPtCreate(const VerificValoriPtCreate& v) {
		this->valori = v.valori;
	}
	VerificValoriPtCreate operator=(const VerificValoriPtCreate& v) {
		this->valori = v.valori;
		return *this;
	}
	friend istream& operator>>(istream& citire, VerificValoriPtCreate& v) {
		citire >> v.valori;
	}
	friend ostream& operator<<(ostream& afisare, VerificValoriPtCreate v) {
		afisare << "Nr de valori este:" << v.valori;
		afisare << endl;
		return afisare;
	}


};



//VERIFICAM TIPUL DE COMANDA SI CORECTITUDINEA EI
class Parsare {

	string comanda;
public:
	int index;
	Parsare() {
		this->comanda = "";
	}
	Parsare(string comanda) {
		this->comanda = comanda;

	}
	string getComanda() {
		return this->comanda;
	}
	void setComanda(string comanda) {

		this->comanda = comanda;
	}
	~Parsare() {

	}
	Parsare(const Parsare& p) {
		this->comanda = p.comanda;
	}
	Parsare operator=(const Parsare& p) {
		this->comanda = p.comanda;
		return *this;
	}

	friend istream& operator>>(istream& citire, Parsare& p) {
		citire >> p.comanda;
	}
	friend ostream& operator<<(ostream& afisare, Parsare p) {
		afisare << "Comanda introdusa este :" << p.comanda;
		afisare << endl;
		return afisare;
	}
	// ACEASTA FUNCTIE VERIFICA CORECTITUDINEA COMENZII INTRODUSA DE LA TASTATURA
	void functie() {

		string aux2; string aux3;
		string aux;
		//SALVAM PRIMUL CUVANT
		for (int i = 0; i < this->comanda.length(); i++) {
			if (this->comanda[i] != ' ') {
				aux += this->comanda[i];
			}
			else {
				index = i++;
				break;
			}
		}

		if (aux == "CREATE") {
			//VERIFICAM AL DOILEA CUVANT
			index++;

			while (this->comanda[index] != ' ' && index != this->comanda.length()) {
				aux2 += this->comanda[index];
				index++;

			}
			if (aux2 != "TABLE") {
				cout << "Al doilea cuvant cheie gresit!";
			}

			else if (aux2 == "TABLE") {
				index++;
				//AFLAM NUMELE TABELEI
				while (this->comanda[index] != ' ' && this->comanda[index] != '(' && index != this->comanda.length()) {

					aux3 += this->comanda[index];
					index++;
				}

				

				int ok2 = 0; string s = "";
				
				
				numeTab.open("numeTabele", fstream::in | fstream::app);

				while (getline(numeTab, s) && ok2 == 0) {

					if (s == aux3)ok2 = 1;

				}
				numeTab.close();
				if (ok2 == 1)aux3 = "";

				if (aux3.length() < 2)cout << "Nu ai introdus numele tabelei sau tabela exista deja!";
				else if (aux3.length() > 3) {
					//cout << "Se vrea crearea tabelei " << aux3;
					//COPIEM INTR-UN STRING CE SE AFLA INTRE () LA COMANDA CREATE
					//indexul este pe prima (
					//CREATE TABLE students((id, integer, 1000, 0), (nume, text, 128, ’’), (grupa, text, 50, ’1000’))
					index++;
					if (this->comanda[index] != '(' || this->comanda[index + 1] != '(' ||
						this->comanda[this->comanda.length() - 1] != ')' || this->comanda[this->comanda.length() - 2] != ')') {
						cout << endl << "Ai introdus gresit! Lipseste o paranteza!";
					}

					else {
						Coloana coloane[100];
						int n = 0;
						int semafor = 1;
						int nrColoane = 0; string aux20[100]; int lungAux20 = 0;

						string aux5[100];

						while (index != this->comanda.length() - 2 && semafor == 1) {
							cout << endl;
							index = index + 1;
							string aux10;
							aux10 = "";
							if (this->comanda[index] == ',')  index++;
							if (this->comanda[index] == ' ')index++;
							while (index != this->comanda.length() - 1 && this->comanda[index] != ')') {
								aux10 += this->comanda[index];
								index++;
							}
							if (this->comanda[index] == ')' || this->comanda[index + 1] == ')')
								aux10 += this->comanda[index];

							if (aux10[0] != '(' || aux10[aux10.length() - 1] != ')') {
								semafor = 0;
								cout << endl << "Ai introdus gresit!Lipseste o paranteza!"; break;
							}

							else {
								//(id, integer, 1000, 0), (nume, text, 128, ’’), (grupa, text,50,’1000’)

								int lungimeParanteza = aux10.length();
								int i = 1;
								nrColoane = 0;
								while (i != aux10.length() - 1 && semafor == 1) {
									aux5[nrColoane] = "";
									while (aux10[i] != ',' && aux10[i] != ')') {

										aux5[nrColoane] += aux10[i];
										i++;

									}
									if (aux5[nrColoane] == "")semafor = 0;

									nrColoane++;

									while (aux10[i] == ' ' || aux10[i] == ',' || aux10[i] == '(')i++;

								}

								// tip coloana gresit(tipuri acceptate sunt text, integer, float)

								if (aux5[1] != "text" && aux5[1] != "integer" && aux5[1] != "float") {
									semafor = 0;
									cout << endl
										<< "Ai introdus gresit!tip coloana gresit (tipuri acceptate sunt text, integer, float)";
									break;
								}

								if (semafor == 1) {

									for (int k = 0; k < nrColoane; k++) {
										aux20[lungAux20++] = aux5[k];

									}
								}

								if (semafor == 0) { cout << "Ai introdus gresit!"; break; }

								if (nrColoane != 4) {
									semafor = 0;
									cout << "*, Ai introdus gresit ";
									break;
								}

							}
						}

						if (semafor == 1)
						{
							int n = 0;
							Coloana coloane[100];
							int i = 0;
							while (i < lungAux20)
							{
								if (aux20[i] == "''")aux20[i] = "-";
								else if (aux20[i] != "''" && aux20[i][0] == 39)
								{
									aux20[i][aux20[i].length() - 1] = NULL;

									int j = 0;
									while (j != aux20[i].length() - 1)
									{
										aux20[i][j] = aux20[i][j + 1];
										j++;
									}
								}

								i++;

							}
							i = 0;
							cout << "TABELA " << aux3 << " a fost creata" << endl;

							while (i < lungAux20)
							{
								string auxiliar1 = "";
								string auxiliar2 = "";
								int auxiliar3 = 0;
								string auxiliar4 = "";

								auxiliar1 = aux20[i];
								auxiliar2 = aux20[i + 1];
								auxiliar3 = stoi(aux20[i + 2]);
								auxiliar4 = aux20[i + 3];
								Coloana c(auxiliar1, auxiliar2, auxiliar3, auxiliar4);

								coloane[n] = c;
								n++;
								i = i + 4;
							}

							Create tabela(aux3, n, coloane);
							tabela.afisareTabela();
							//
							ofstream f(aux3 + ".bin", ios::binary);
							//
							tabela.scrieTabela(f);
							tabela.scrieTabela(fisierTabele);
							numeTab.open("numeTabele", fstream::out | fstream::app);

							numeTab << aux3 << endl;
							g << aux3 << endl;
							numeTab.close();
							g << n << endl;
							for (i = 0; i < lungAux20; i++) {
								g << aux20[i] << endl;
							}

						}
					}
				}
			}

		}

		else if (aux == "DROP" || aux == "DISPLAY") {

			//VERIFICAM AL DOILEA CUVANT
			index++;

			while (this->comanda[index] != ' ' && this->comanda[index] != NULL) {
				aux2 += this->comanda[index];
				index++;

			}

			if (aux2 == "TABLE") {

				//AFLAM NUMELE TABELEI
				int Ok = 1;
				while (this->comanda[index] == ' ')index++;
				while (index != this->comanda.length()) {

					if (this->comanda[index + 1] == ' ' || this->comanda[index + 1] == ',') {
						cout << "Numele trebuie sa fie un cuvant"; break; Ok = 0;
					}
					else 	aux3 += this->comanda[index];
					index++;

				}

				int ok2 = 0; string s = "";
				numeTab.open("numeTabele", fstream::in | fstream::app);

				while (getline(numeTab, s) && ok2 == 0) {

					if (s == aux3)ok2 = 1;

				}
				numeTab.close();
				if (ok2 == 0)aux3 = "";
				if (Ok == 1) {
					if (aux3.length() < 2)cout << "Nu ai introdus numele tabelei!" << endl;
					else if (aux3.length() > 3 && aux == "DROP") {
						{cout << "Se  sterge tabela " << aux3 << endl;
						
						
							char char_nume_tabel[30] = "";

							strcpy(char_nume_tabel, aux3.c_str());
							strcat(char_nume_tabel, ".bin");


							ifstream Fisier(aux3 + ".bin", ios::_Nocreate);
							Fisier.close();

							if (Fisier.fail() == 0)
							{
								Fisier.close();
								remove(char_nume_tabel);
								cout << "Fisierul a fost sters" << endl;
							}
							else {
								cout << "Fisierul nu exista";
							}
						
						
						
						
						}

					}
					else if (aux3.length() > 3 && aux == "DISPLAY") {
						cout << "Se afiseaza tabela " << aux3 << endl;
						g.open("date.txt", fstream::in | fstream::app);
						string s; int ok = 0;
						while (getline(g,s)&&ok==0) {
							if (s == aux3) {
								
								ok = 1;
								string x;
								getline(g,x);
								cout << "Nr de coloane:" << x<<endl;
								int n = stoi(x);
								for (int k = 0; k < n * 4;k++)
								{
									string l;
									getline(g, l);
									cout << l << " ";


								}
							}

						}
						g.close();
						cout << endl;


					}
				}
			}
			else  if (aux2 != "TABLE") {
				cout << "Al doilea cuvant cheie gresit!";
			}

		}

		else if (aux == "INSERT") {
			ComenziCrudInsert c(this->comanda);
			c.functieCrudInsert();
		}

		else if (aux == "DELETE") { //cout << " Se incearca stergerea unei coloane!";
			ComenziCrudDelete c(this->comanda);
			c.functieCrudDelete();
		}

		else if (aux == "SELECT") {// cout << "Se doreste vizualizarea unei coloane! "; 

			ComenziCrudSelect c(this->comanda);

			c.functieCrudSelect();
		}
		else if (aux == "UPDATE") {
			ComenziCrudUpdate c(this->comanda);
			c.functieCrudUpdate();

			//cout<<"Se incearca modificarea unor valori din tabela!"; 
		}

		else if ((aux != "CREATE") || (aux != "DROP") || (aux != "DISPLAY") || (aux != "INSERT") || (aux != "UPDATE")
			|| (aux != "DELETE" || aux != "SELECT")) {
			cout << "Primul cuvant cheie este gresit!";
		}

	}
};
class Magazin :public Create {
	int cod_magazin;
public:
	
	Magazin() :Create()
	{
	}
	Magazin(int Cod_magazin,string Denumire) :Create(Denumire) {
		this->cod_magazin = Cod_magazin;

	}
	Magazin(int Cod_magazin, string nume_tabel, int nrColoane, Coloana* coloane) :Create(nume_tabel, nrColoane, coloane)
	{
		this->cod_magazin = Cod_magazin;
	}
	~Magazin() {

	}
	
	virtual void functieAfis() {
		cout << "Numele magazinului este : ";
		cout << this->getNume_Tabel();
		cout << " si are codul" << this->cod_magazin;

	}

};

int main(int argc, char* argv[]) {

	ifstream f("comanda.in");
	string s;
	//cout << "Introduceti comanda:" << endl;
	while (getline(f, s))
	{

		try {
			Parsare p(s);
			p.functie();
		}
		catch (Exceptie) {
			cout << "Comanda introdusa este incorecta!";
		};

	}
}

